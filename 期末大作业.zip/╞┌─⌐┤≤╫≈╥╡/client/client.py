# -*- coding: utf-8 -*-
import os
import socket
import sys
import threading
from PyQt5.QtWidgets import QAction, QApplication, QFileDialog, QMainWindow, QMenuBar, QWidget, QLabel, QLineEdit, QPushButton, QTextEdit, QColorDialog, QVBoxLayout, QHBoxLayout, QFontDialog
from PyQt5.QtGui import QBrush, QPalette, QColor, QFont, QIcon, QPixmap
from PyQt5.QtCore import QSize

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        # 设置窗口标题
        self.setWindowTitle("客户端登录")
        # 主布局
        main_layout = QVBoxLayout()
        # 设置窗口大小
        self.setFixedSize(500, 400)
        # 添加图片
        image_label = QLabel(self)

        import os
        # 获取当前脚本所在目录
        base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))

        # 构建图片路径
        image_path = os.path.join(base_path, "py", "1.jpg")

        pixmap = QPixmap(image_path)
        image_label.setPixmap(pixmap)
        #设置图片布局方式
        image_label.setScaledContents(True)
        # 设置图片大小
        image_label.setFixedSize(680, 420)  # 调整为合适的大小
        #将图片社设置为背景
        palette = self.palette()
        palette.setBrush(QPalette.Background, QBrush(pixmap))
        self.setPalette(palette)
        # IP 布局
        ip_layout = QHBoxLayout()
        self.server_ip_label = QLabel("服务器IP地址:", self)
        self.server_ip_edit = QLineEdit(self)
        ip_layout.addWidget(self.server_ip_label)
        ip_layout.addWidget(self.server_ip_edit)
        # 端口布局
        port_layout = QHBoxLayout()
        self.server_port_label = QLabel("服务器端口:", self)
        self.server_port_edit = QLineEdit(self)
        port_layout.addWidget(self.server_port_label)
        port_layout.addWidget(self.server_port_edit)
        # 按钮布局
        button_layout = QHBoxLayout()
        self.login_button = QPushButton("登录", self)
        button_layout.addWidget(self.login_button)
        # 其他部件添加到主布局
        main_layout.addLayout(ip_layout)
        main_layout.addLayout(port_layout)
        main_layout.addWidget(self.login_button)
        # 设置窗口布局
        self.setLayout(main_layout)
        # 连接信号与槽
        self.login_button.clicked.connect(self.login)
        # 设置窗口大小
        self.setMaximumSize(680, 420)

    def login(self):
        # 获取IP和端口
        server_ip = self.server_ip_edit.text()
        server_port = int(self.server_port_edit.text())
        # 在这里可以添加登录验证逻辑
        # 登录成功后，显示聊天界面
        self.show_chat_window(server_ip, server_port)

    def show_chat_window(self, server_ip, server_port):
        self.chat_window = ChatWindow(server_ip, server_port)
        self.chat_window.show()
        self.close()

class ChatWindow(QMainWindow):
    def __init__(self, server_ip, server_port):
        super().__init__()
        self.server_ip = server_ip
        self.server_port = server_port
        self.init_ui()

    def init_ui(self):
        # 设置窗口标题
        self.setWindowTitle("客户端聊天")
        # 主布局
        main_layout = QVBoxLayout()
        # 设置窗口大小
        self.setFixedSize(720, 550)
        # 消息布局
        message_layout = QHBoxLayout()
        self.message_label = QLabel("消息:", self)
        self.message_edit = QLineEdit(self)
        self.send_button = QPushButton("发送", self)
        #设置按钮大小
        self.send_button.setFixedSize(120, 40)
        message_layout.addWidget(self.message_label)
        message_layout.addWidget(self.message_edit)
        message_layout.addWidget(self.send_button)
        # 按钮布局
        button_layout = QHBoxLayout()
        self.start_button = QPushButton("启动连接", self)
        button_layout.addWidget(self.start_button)
        # 其他部件添加到主布局
        self.log_text = QTextEdit(self)
        main_layout.addWidget(self.log_text)
        main_layout.addLayout(message_layout)
        self.file_button = QPushButton("发送文件", self)
        #设置按钮大小
        self.file_button.setFixedSize(120, 40)
        message_layout.addWidget(self.file_button)
        self.file_button.clicked.connect(self.send_file)
        main_layout.addWidget(self.start_button)
        # 设置窗口布局
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)
        # 连接信号与槽
        self.start_button.clicked.connect(self.start_connection_thread)
        self.message_edit.returnPressed.connect(self.send_message)
        self.send_button.clicked.connect(self.send_message)
        # 初始化套接字与线程对象
        self.client_socket = None
        self.connected = False
        self.thread = None
        
        # 添加菜单栏
        menu_bar = QMenuBar(self)
        self.setMenuBar(menu_bar)

        # 添加菜单项
        file_menu = menu_bar.addMenu("文件")
        view_menu = menu_bar.addMenu("视图")

        # 为菜单项添加动作
        new_action = QAction("新建", self)
        new_action.triggered.connect(self.init_ui)  
        exit_action = QAction("退出", self)
        exit_action.triggered.connect(self.closeEvent)

        file_menu.addAction(new_action)
        file_menu.addSeparator()
        file_menu.addAction(exit_action)

        # 为视图菜单项添加动作
        color_action = QAction("选择颜色", self)
        color_action.triggered.connect(self.choose_color)
        font_action = QAction("选择字体", self)
        font_action.triggered.connect(self.choose_font)

        view_menu.addAction(color_action)
        view_menu.addAction(font_action)

        self.setMaximumSize(1280, 960)

    def start_connection_thread(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self.connect_to_server)
        self.thread.start()
        # 启动连接线程
        #使用了TCP协议的套接字，创建了一个套接字对象self.client_socket
        #使用connect方法连接到指定的服务器地址和端口
        #如果连接成功，将self.connected设置为True，并在日志中显示连接成功的消息
        #如果连接失败，捕获异常并在日志中显示连接失败的消息
        #在while循环中，使用recv方法接收服务器发送的数据，并将其显示在日志中
    def connect_to_server(self):
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.client_socket.connect((self.server_ip, self.server_port))
            self.connected = True
            self.log_text.append("连接成功")
        except Exception as e:
            self.log_text.append(f"连接失败: {e}")
        while self.connected:
            try:
                data = self.client_socket.recv(1024).decode('utf-8')
                if data:
                    self.log_text.append(f"收到消息: {data}")
            except Exception as e:
                if self.connected:
                    self.log_text.append(f"接收消息出错: {e}")

    def send_message(self):
        if not self.connected:
            self.log_text.append("尚未连接到服务器，无法发送消息")
            return
        message = self.message_edit.text()
        try:
            self.client_socket.send(message.encode('utf-8'))
            self.log_text.append(f"发送消息: {message}")
            self.message_edit.clear()
            self.log_text.ensureCursorVisible()
        except Exception as e:
            self.log_text.append(f"发送消息时出错: {e}")

    def choose_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            palette = QPalette()
            palette.setColor(QPalette.Window, color)
            self.setPalette(palette)

    def choose_font(self):
        font, ok = QFontDialog.getFont()
        if ok:
            self.log_text.setFont(font)

    def resizeEvent(self, event):
        new_width = event.size().width()
        new_height = event.size().height()
        # 根据窗口大小调整UI元素的大小和位置
        super().resizeEvent(event)
    def send_file(self):
        if not self.connected:
            self.log_text.append("未连接到服务器，无法发送文件")
            return

        file_path, _ = QFileDialog.getOpenFileName(self, "选择要发送的文件", "", "All Files (*)")
        if file_path:
            with open(file_path, 'rb') as file:
                file_data = file.read()
            # 在这里添加发送文件数据的逻辑
            # 例如，使用 socket 发送文件数据
            try:
                self.client_socket.send(file_data)
                self.log_text.append(f"发送文件: {file_path}")
            except socket.error as e:
                self.log_text.append(f"发送文件失败: {e}")
    def closeEvent(self, event):
        # 在关闭窗口时关闭套接字
        if self.client_socket:
            self.client_socket.close()
        event.accept()

    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    # 获取当前脚本所在目录
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    # 构建图片路径
    app_ph = os.path.join(base_path, "py", "1.jpg")
    # 设置应用程序图标
    app.setWindowIcon(QIcon(app_ph))
    font = QFont("Arial", 12)
    app.setFont(font)
    login_win = LoginWindow()
    login_win.show()
    sys.exit(app.exec_())
