# -*- coding: utf-8 -*-
import os #读取路径
import socket
import sys
import threading
from PyQt5.QtWidgets import QAction, QApplication, QFileDialog, QFontDialog, QMainWindow, QMenuBar, QWidget, QLabel, QLineEdit, QPushButton, QTextEdit, QColorDialog, QVBoxLayout, QHBoxLayout
from PyQt5.QtGui import QBrush, QIcon, QPalette, QFont, QPixmap


#登录窗口
class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        # 主布局
        main_layout = QVBoxLayout()
        self.setFixedSize(500, 400)
        # 设置窗口标题
        self.setWindowTitle("服务器登录")
        # 添加图片
        image_label = QLabel(self)
        # 获取脚本所在的目录或 PyInstaller 临时目录
        base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        # 构建图片路径
        image_path = os.path.join(base_path, "py", "2.jpg")
        pixmap = QPixmap(image_path)
        image_label.setPixmap(pixmap)
        #设置图片布局方式
        image_label.setScaledContents(True)
        # 设置图片大小
        image_label.setFixedSize(680, 420)  # 调整为合适的大小
        #将图片社设置为背景
        palette = self.palette()
        palette.setBrush(QPalette.Background, QBrush(pixmap))
        self.setPalette(palette)


        # IP 布局
        ip_layout = QHBoxLayout()
        self.ip_label = QLabel("IP 地址:", self) 
        self.ip_edit = QLineEdit(self)
        ip_layout.addWidget(self.ip_label)  
        ip_layout.addWidget(self.ip_edit)
        # 端口布局
        port_layout = QHBoxLayout()
        self.port_label = QLabel("端口:", self)
        self.port_edit = QLineEdit(self)
        port_layout.addWidget(self.port_label)
        port_layout.addWidget(self.port_edit)
        # 按钮布局
        button_layout = QHBoxLayout()
        self.login_button = QPushButton("登录", self)
        button_layout.addWidget(self.login_button)
        # 其他部件添加到主布局
        
        main_layout.addLayout(ip_layout)
        main_layout.addLayout(port_layout)
        main_layout.addWidget(self.login_button) 
        # 设置窗口布局
        self.setLayout(main_layout)
        # 连接信号与槽
        self.login_button.clicked.connect(self.login)  # 连接登录按钮的点击事件
        
        # 设置窗口大小
        self.setMaximumSize(680, 420)
        
        
        

    def login(self):
        # 获取IP和端口
        ip = self.ip_edit.text()
        try:
            port = int(self.port_edit.text())
        except ValueError:
            print("端口号必须是整数")
            return
        # 在这里可以添加登录验证逻辑
        # 登录成功后，显示聊天界面
        self.show_chat_window(ip, port)
#展示聊天窗口
    def show_chat_window(self, ip, port):
        self.chat_window = ChatWindow(ip, port)
        self.chat_window.show()
        self.close()

#聊天窗口
class ChatWindow(QMainWindow):  # 继承自 QWidget
    def __init__(self, ip, port):
        super().__init__()  # 调用父类的构造函数
        self.ip = ip
        self.port = port
        self.init_ui() # 调用 init_ui 方法

    def init_ui(self):
        # 设置窗口标题
        self.setWindowTitle("服务器聊天")
        # 主布局
        main_layout = QVBoxLayout()
        # 设置窗口大小
        self.setFixedSize(720, 550)
        # 消息布局
        message_layout = QHBoxLayout()
        self.message_label = QLabel("消息:", self)
        self.message_edit = QLineEdit(self)
        self.send_to_client_button = QPushButton("发送给客户端", self)
        message_layout.addWidget(self.message_label)
        message_layout.addWidget(self.message_edit)
        message_layout.addWidget(self.send_to_client_button)
        # 按钮布局
        button_layout = QHBoxLayout()
        self.start_button = QPushButton("启动服务器", self)
        button_layout.addWidget(self.start_button)
        # 其他部件添加到主布局
        self.file_button = QPushButton("发送文件", self)
        message_layout.addWidget(self.file_button)
        self.file_button.clicked.connect(self.send_file)
        self.log_text = QTextEdit(self)
        
        main_layout.addWidget(self.log_text)
        main_layout.addLayout(message_layout)
        main_layout.addWidget(self.start_button)
        # 设置窗口布局
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)
        # 连接信号与槽
        self.start_button.clicked.connect(self.start_server_thread)
        self.message_edit.returnPressed.connect(self.send_message_to_client)
        self.send_to_client_button.clicked.connect(self.send_message_to_client)
        # 初始化套接字与线程对象
        self.server_socket = None
        self.client_socket = None
        self.thread = None

        # 添加菜单栏
        menu_bar = QMenuBar(self)
        self.setMenuBar(menu_bar)

        # 添加菜单项
        file_menu = menu_bar.addMenu("文件")
        view_menu = menu_bar.addMenu("视图")

        # 为菜单项添加动作
        new_action = QAction("新建", self)
        new_action.triggered.connect(self.init_ui)  
        exit_action = QAction("退出", self)
        exit_action.triggered.connect(self.close)

        file_menu.addAction(new_action)
        file_menu.addSeparator()
        file_menu.addAction(exit_action)

        # 为视图菜单项添加动作
        color_action = QAction("选择颜色", self)
        color_action.triggered.connect(self.choose_color)
        font_action = QAction("选择字体", self)
        font_action.triggered.connect(self.choose_font)

        view_menu.addAction(color_action)
        view_menu.addAction(font_action)
        self.setMaximumSize(1280, 960)
    def start_server_thread(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self.start_server)
        self.thread.start()

    def start_server(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind((self.ip, self.port))
        self.server_socket.listen(1)
        self.log_text.append("服务器启动，等待连接...")
        self.client_socket, client_address = self.server_socket.accept()
        self.log_text.append(f"连接来自: {client_address}")
        while True:
            try:
                data = self.client_socket.recv(1024).decode('utf-8')
                if not data:
                    break
                self.log_text.append(f"收到消息: {data}")
            except Exception as e:
                self.log_text.append(f"接收消息出错: {e}")

    def send_message_to_client(self):
        message = self.message_edit.text()
        if self.client_socket:
            try:
                self.client_socket.send(message.encode('utf-8'))
                self.log_text.append(f"发送消息给客户端: {message}")
                self.message_edit.clear()
            except Exception as e:
                self.log_text.append(f"发送消息出错: {e}")
        else:
            self.log_text.append("尚未与客户端建立连接，无法发送消息")

    def choose_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            palette = QPalette()
            palette.setColor(QPalette.Window, color)
            self.setPalette(palette)

    def choose_font(self):
        font, ok = QFontDialog.getFont()
        if ok:
            self.log_text.setFont(font)

#接受文件的内的内容
    def send_file(self):
    # 如果没有客户端连接，无法发送文件
        if not self.server_socket:
            self.log_text.append("未启动服务器，无法发送文件")
            return
    # 如果没有客户端连接，无法发送文件
        if not self.client_socket:
            self.log_text.append("未连接到客户端，无法发送文件")
            return
    # 如果有客户端连接，选择文件
        file_path, _ = QFileDialog.getOpenFileName(self, "选择要发送的文件", "", "All Files (*)")
    # 如果选择了文件，读取文件数据
        if file_path:
            with open(file_path, 'rb') as file:
                while True:
                    file_data = file.read(1024)  # 每次读取 1024 字节
                    if not file_data:
                        break  # 文件读取完毕
                # 在这里添加发送文件数据的逻辑
                # 例如，使用 socket 发送文件数据
                    try:
                        self.client_socket.send(file_data)
                        self.log_text.append(f"发送文件: {file_path}")
                    except socket.error as e:
                        self.log_text.append(f"发送文件失败: {e}")
                        break  # 发送失败，停止发送
        else:
            self.log_text.append("未选择文件")
    # 移除了 resizeEvent 方法，因为它可能导致布局混乱
    def closeEvent(self, event):
        # 在关闭窗口时关闭套接字
        if self.server_socket:
            self.server_socket.close()
        if self.client_socket:
            self.client_socket.close()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # 获取脚本所在的目录或 PyInstaller 临时目录
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        # 构建图片路径
    app_ph = os.path.join(base_path, "py", "1.jpg")
    # 设置应用程序图标
    app.setWindowIcon(QIcon(app_ph))
    # 设置全局字体
    font = QFont("Arial", 12)
    app.setFont(font)
    login_win = LoginWindow()
    login_win.show()
    sys.exit(app.exec_())
